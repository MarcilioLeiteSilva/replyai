
import json, os, threading, time
from flask import Flask, jsonify, render_template
import config

app = Flask(__name__)

agent_running = False
responses_count = 0
agent_thread = None

def run_agent():
    global agent_running, responses_count
    agent_running = True
    responses_count = 0
    while agent_running and responses_count < config.MAX_RESPONSES:
        time.sleep(4)
        save_history(f"Comentário {responses_count+1}", "Resposta automática 😊")
        responses_count += 1
    agent_running = False

def save_history(comment, response):
    history = []
    if os.path.exists("history.json"):
        history = json.load(open("history.json", encoding="utf-8"))
    history.append({"comment": comment, "response": response})
    json.dump(history, open("history.json","w",encoding="utf-8"), ensure_ascii=False, indent=2)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/start", methods=["POST"])
def start():
    global agent_thread
    if not agent_running:
        agent_thread = threading.Thread(target=run_agent, daemon=True)
        agent_thread.start()
    return jsonify({"ok": True})

@app.route("/status")
def status():
    return jsonify({"running": agent_running,"count":responses_count,"max":config.MAX_RESPONSES})

@app.route("/history")
def history():
    if not os.path.exists("history.json"):
        return jsonify([])
    return jsonify(json.load(open("history.json",encoding="utf-8")))

if __name__ == "__main__":
    app.run(debug=True)
