import shutil
import os

src = r"c:\Users\Win11_001\Desktop\agente-comentarios-yt"
dst = r"c:\Users\Win11_001\Desktop\agente-comentarios-yt\agente-comentarios-yt_Backup"

print("Preparando os arquivos e limpando lixos...")
def ignore_files(dir, files):
    ignore_list = set()
    for f in files:
        if f in ['.git', 'node_modules', '.next', 'venv', '__pycache__', '.pytest_cache', 'agente-comentarios-yt_Backup', 'agente-comentarios-yt_Backup.zip']:
            ignore_list.add(f)
    return ignore_list

if os.path.exists(dst):
    shutil.rmtree(dst)
if os.path.exists(dst + ".zip"):
    os.remove(dst + ".zip")

shutil.copytree(src, dst, ignore=ignore_files)

print("Criando o arquivo ZIP...")
shutil.make_archive(dst, 'zip', dst)

print("Limpando sobras...")
shutil.rmtree(dst)

print("Backup completo: " + dst + ".zip")
