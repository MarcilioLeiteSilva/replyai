{
  "scripts": {
    "build": "seed_plans"
  }
}
